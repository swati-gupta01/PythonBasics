from setuptools import setup
setup(
    name='sum',
    version='1.0',
    description='Swat code',
    author='swati',
    author_email='swa.gupta01@gmail.com',
    url='swa.gupta.com',
    py_modules=['sum']
)